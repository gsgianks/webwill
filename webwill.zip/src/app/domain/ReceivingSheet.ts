export class ReceivingSheet {
    id: number;
    idUsuario: number;
    idMotocicleta: number;
    trabajoRealizar: string;
    observaciones: string;
    fechaIngreso: string;
    fechaSalida: string;
}
