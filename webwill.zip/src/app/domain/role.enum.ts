export enum Role {
    AdminSupplier = 'admin_supplier',
    AdminProduct = 'admin_product',
    None = ''
}
