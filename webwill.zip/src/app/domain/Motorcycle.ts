export class Motorcycle {
    id: number;
    numeroPlaca: string;
    marca: string;
    modelo: string;
    ano: string;
    serieMarco: string;
    serieMotor: string;
    anotaciones: string;
    imagenPerfil: string;
    idUsuario: number;
    idPlaca: number;
    idPlan: number;
    imagen: File;
}
