export class Maintenance {
    id: number;
    idHojaRecibimiento: number;
    idMecanico: number;
    repuesto: string;
    descripcion: string;
    monto: number;
    fecha: string;
}
