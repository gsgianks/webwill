export class Answer {
    code: number;
    description: string;
}
