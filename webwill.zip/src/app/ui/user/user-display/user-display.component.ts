import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mot-user-display',
  templateUrl: './user-display.component.html',
  styleUrls: ['./user-display.component.scss']
})
export class UserDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
