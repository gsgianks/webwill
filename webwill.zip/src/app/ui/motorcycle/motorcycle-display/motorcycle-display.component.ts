import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mot-motorcycle-display',
  templateUrl: './motorcycle-display.component.html',
  styleUrls: ['./motorcycle-display.component.scss']
})
export class MotorcycleDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
