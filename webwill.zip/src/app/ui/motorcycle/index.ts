export { MotorcycleDisplayComponent } from './motorcycle-display/Motorcycle-display.component';
export { MotorcycleViewComponent } from './motorcycle-view/Motorcycle-view.component';
export { MotorcycleEditComponent } from './motorcycle-edit/Motorcycle-edit.component';
export { MotorcycleGridComponent } from './motorcycle-grid/Motorcycle-grid.component';
export { MotorcycleListUserComponent } from './motorcycle-list-user/motorcycle-list-user.component';
