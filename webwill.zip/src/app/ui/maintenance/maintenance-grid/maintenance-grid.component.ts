import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mot-maintenance-grid',
  templateUrl: './maintenance-grid.component.html',
  styleUrls: ['./maintenance-grid.component.scss']
})
export class MaintenanceGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
