import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mot-maintenance-display',
  templateUrl: './maintenance-display.component.html',
  styleUrls: ['./maintenance-display.component.scss']
})
export class MaintenanceDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
