import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mot-maintenance-view',
  templateUrl: './maintenance-view.component.html',
  styleUrls: ['./maintenance-view.component.scss']
})
export class MaintenanceViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
