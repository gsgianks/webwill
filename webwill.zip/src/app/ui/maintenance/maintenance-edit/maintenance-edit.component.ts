import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mot-maintenance-edit',
  templateUrl: './maintenance-edit.component.html',
  styleUrls: ['./maintenance-edit.component.scss']
})
export class MaintenanceEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
