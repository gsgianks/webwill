import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mot-receivingsheet-display',
  templateUrl: './receivingsheet-display.component.html',
  styleUrls: ['./receivingsheet-display.component.scss']
})
export class ReceivingSheetDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
